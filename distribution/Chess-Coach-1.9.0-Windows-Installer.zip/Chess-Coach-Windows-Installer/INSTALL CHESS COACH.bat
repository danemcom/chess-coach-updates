@echo off
setlocal
cd /d "%~dp0"
if not exist "Payload\ChessCoach.exe" (
    echo ERROR: Extract the entire installer ZIP first. Keep the Payload folder beside this file.
echo BLAD: Najpierw wypakuj cale archiwum ZIP. Folder Payload musi pozostac obok tego pliku.
    pause
    exit /b 1
)
echo Chess Coach Desktop - Automatic Windows Installer
echo Chess Coach Desktop - Automatyczny instalator Windows
echo.
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0ChessCoach-Setup.ps1"
if errorlevel 1 (
    echo.
    echo Setup stopped. Read the error shown above and rerun this file to retry.
echo Instalacja zatrzymana. Sprawdz blad powyzej i uruchom plik ponownie.
    pause
    exit /b 1
)
echo.
echo Setup complete.
echo Instalacja zakonczona.
pause
endlocal
