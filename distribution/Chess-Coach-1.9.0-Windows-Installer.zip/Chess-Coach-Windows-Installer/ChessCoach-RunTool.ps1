param([ValidateSet('stockfish','maia5','maiaLarge','leelaGpu','leelaCpu','puzzles','health')][string]$Tool)
$ErrorActionPreference='Stop'
try {
 $base=Join-Path $env:LOCALAPPDATA 'Programs\Chess Coach'
 $exe=Join-Path $base 'ChessCoach.exe'
 if(-not (Test-Path -LiteralPath $exe -PathType Leaf)){throw 'Install the compiled Chess Coach first.'}
 Set-Location -LiteralPath $base
 switch($Tool) {
  'stockfish' { & $exe '--tool' 'stockfish' }
  'maia5' { & $exe '--tool' 'maia3' '--model' '5m' }
  'maiaLarge' { & $exe '--tool' 'maia3' '--model' '23m'; if($LASTEXITCODE -ne 0){throw 'Maia 23M failed.'}; & $exe '--tool' 'maia3' '--model' '79m' }
  'leelaGpu' { & $exe '--tool' 'leela' '--mode' 'gpu' }
  'leelaCpu' { & $exe '--tool' 'leela' '--mode' 'cpu' }
  'health' { & $exe '--tool' 'health' }
  'puzzles' {
    $answer=(Read-Host 'Download A=all puzzles, S=20,000 sample, N=cancel').Trim().ToUpperInvariant()
    if($answer -notin @('A','S')){exit 0}
    if($answer -eq 'A'){
        $disk=[System.IO.DriveInfo]::new([System.IO.Path]::GetPathRoot($env:LOCALAPPDATA))
        if($disk.AvailableFreeSpace -lt 5GB){throw 'Full puzzle import requires at least 5 GB free space.'}
        & $exe '--tool' 'puzzles' '--download' '--all'
    } else { & $exe '--tool' 'puzzles' '--download' '--max' '20000' '--scan' '500000' }
  }
 }
 if($LASTEXITCODE -ne 0){throw ($Tool+' exited with code '+$LASTEXITCODE)}
 Write-Host ($Tool+' complete.') -ForegroundColor Green
 exit 0
}catch{Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red;exit 1}
