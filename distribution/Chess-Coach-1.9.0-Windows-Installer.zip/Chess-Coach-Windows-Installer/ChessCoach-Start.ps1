$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
$exe=Join-Path $base 'ChessCoach.exe'
if(-not (Test-Path -LiteralPath $exe -PathType Leaf)){throw 'Compiled Chess Coach executable missing. Rerun setup.'}
if(-not (Test-Path -LiteralPath (Join-Path $base 'engine\stockfish.exe'))){throw 'Stockfish is missing. Rerun setup.'}
try{
 $running=$null
 try{$running=Invoke-RestMethod -Uri 'http://127.0.0.1:48319/api/status' -TimeoutSec 1 -ErrorAction Stop}catch{}
 if($running -and ($null -ne $running.ready)){Start-Process 'http://127.0.0.1:48319/';exit 0}
 & $exe
 if($LASTEXITCODE -ne 0){throw ('Chess Coach exited with code '+$LASTEXITCODE)}
}catch{Write-Host ('Chess Coach could not start: '+$_.Exception.Message) -ForegroundColor Red;Read-Host 'Press Enter to close';exit 1}
