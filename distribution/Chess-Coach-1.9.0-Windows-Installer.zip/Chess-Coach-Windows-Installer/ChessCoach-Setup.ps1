# Chess Coach Windows installer; package version is read from Payload/VERSION.
# PowerShell 5.1+, Windows 10/11 x64. No elevation or system policy changes.
# Stockfish, Lc0, and Python downloads use official HTTPS endpoints.
param([switch]$NoGUI,[switch]$CoreOnly,[switch]$NoDesktopShortcut,[string]$ReuseEngineFrom='', [switch]$AllPuzzles)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$script:Base = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:Source = Join-Path $script:Base 'Payload'
$script:AppVersion = (Get-Content -LiteralPath (Join-Path $script:Source 'VERSION') -Encoding UTF8 | Select-Object -First 1).Trim()
if ($script:AppVersion -notmatch '^\d+\.\d+\.\d+$') { throw 'Invalid Chess Coach VERSION file.' }
$script:InstallDir = Join-Path $env:LOCALAPPDATA 'Programs\Chess Coach'
# The name changes only when the artwork changes, avoiding Windows' stale icon
# cache without accumulating a separate ICO for every app version.
$script:ContentIconName = 'ChessCoach-icon-' + (Get-FileHash -LiteralPath (Join-Path $script:Base 'ChessCoach.ico') -Algorithm SHA256).Hash.Substring(0,12).ToLowerInvariant() + '.ico'
$script:StateDir = Join-Path $env:LOCALAPPDATA 'ChessCoach'
$script:PythonVersion = '3.13.17'
$script:PythonUrl = 'https://www.python.org/ftp/python/3.13.17/python-3.13.17-amd64.exe'
$script:PythonSHA256 = '5da012101ba2e17113a9a1cd901e9ce1441086f2b7ecb5de06ec94163899a190'
$script:MaiaModels=@('5m')
$script:LeelaMode='gpu'
$script:DownloadAllPuzzles=$false
$script:DesktopShortcut=$true
$script:InstallCompleted=$false
$script:Errors = New-Object 'System.Collections.Generic.List[string]'

function Title([string]$message) { Write-Host "`n=== $message ===" -ForegroundColor Cyan }
function Note([string]$message) { Write-Host $message -ForegroundColor Gray }
function Fail([string]$message) { $script:Errors.Add($message); Write-Warning $message }

. (Join-Path $script:Base 'ChessCoach-Python.ps1')

function Find-Python {
    return (Find-ChessCoachPython -AppFolder $script:InstallDir)
}

function Choose-ExistingPython {
    if($NoGUI){return $null}
    Add-Type -AssemblyName System.Windows.Forms
    $answer=[System.Windows.Forms.MessageBox]::Show(
      'Python was not detected automatically. If you already installed Python 3.10-3.14, select its python.exe instead of downloading another copy.'+[Environment]::NewLine+[Environment]::NewLine+'Would you like to locate your existing Python?',
      'Chess Coach - Find existing Python',
      [System.Windows.Forms.MessageBoxButtons]::YesNo,
      [System.Windows.Forms.MessageBoxIcon]::Question)
    if($answer -ne [System.Windows.Forms.DialogResult]::Yes){return $null}
    $picker=New-Object System.Windows.Forms.OpenFileDialog
    $picker.Title='Choose the Python interpreter you already installed'
    $picker.Filter='Python executable (python.exe)|python.exe|Executable files (*.exe)|*.exe'
    $picker.CheckFileExists=$true
    if($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){return $null}
    $ready=Test-ChessCoachPython -Command $picker.FileName
    if($ready){return $ready}
    [void][System.Windows.Forms.MessageBox]::Show(
      'The selected executable could not start, is not 64-bit, or is not Python 3.10-3.14. Setup can download a compatible copy.',
      'Chess Coach - Python check',
      [System.Windows.Forms.MessageBoxButtons]::OK,
      [System.Windows.Forms.MessageBoxIcon]::Warning)
    return $null
}

function Download-VerifiedPython {
    Title 'Installing Python (only because no working compatible Python was found)'
    $runtime=Join-Path $script:InstallDir 'Python313'
    $exe=Join-Path $runtime 'python.exe'
    $existing=Test-ChessCoachPython -Command $exe
    if($existing){return $existing}
    $tmp=Join-Path $env:TEMP ('ChessCoach-Python-'+[Guid]::NewGuid().ToString('N')+'.exe')
    try {
        Note 'Downloading official Python 3.13.17 from python.org (28.6 MB)...'
        [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -UseBasicParsing -Uri $script:PythonUrl -OutFile $tmp -TimeoutSec 900
        $digest=(Get-FileHash -LiteralPath $tmp -Algorithm SHA256).Hash.ToLowerInvariant()
        if($digest -ne $script:PythonSHA256){throw 'Python installer checksum mismatch. Setup stopped.'}
        $signature=Get-AuthenticodeSignature -LiteralPath $tmp
        if($signature.Status -ne 'Valid'){throw ('Official Python installer signature check failed: '+$signature.Status)}
        Note 'SHA-256 and Windows digital signature verified.'
        New-Item -ItemType Directory -Force -Path $runtime|Out-Null
        $args='/quiet InstallAllUsers=0 TargetDir="'+$runtime+'" Include_pip=1 Include_launcher=0 PrependPath=0 Include_test=0 Include_tcltk=0 Shortcuts=0'
        Note 'Installing a private Python runtime without changing your system PATH...'
        $proc=Start-Process -FilePath $tmp -ArgumentList $args -PassThru -Wait
        if($proc.ExitCode -notin @(0,3010)){throw ('Python installer exited with code '+$proc.ExitCode)}
        # Some Python installers register a different user-local location or a
        # Python Install Manager path; do not assume TargetDir was honoured.
        foreach($attempt in 1..3){
            $ready=Test-ChessCoachPython -Command $exe
            if(-not $ready){$ready=Find-Python}
            if($ready){return $ready}
            Start-Sleep -Seconds 2
        }
        Note 'Python installer reported success, but no working interpreter was found at the expected location. Trying a standard per-user Python installation...'
        $args='/quiet InstallAllUsers=0 Include_pip=1 Include_launcher=0 PrependPath=0 Include_test=0 Include_tcltk=0 Shortcuts=0'
        $proc=Start-Process -FilePath $tmp -ArgumentList $args -PassThru -Wait
        if($proc.ExitCode -notin @(0,3010)){Note ('Standard Python installer returned '+$proc.ExitCode)}
        foreach($attempt in 1..3){
            $ready=Find-Python
            if($ready){return $ready}
            Start-Sleep -Seconds 2
        }
        throw 'Python installation finished but could not be verified. Run python --version or py --version in Command Prompt. You can rerun setup and browse to your existing python.exe; your saved Chess Coach data has not been removed.'
    } finally {Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue}
}

function Get-GpuMode {
    try {
        $gpu=@(Get-CimInstance Win32_VideoController -ErrorAction Stop | ForEach-Object {$_.Name}) -join ' | '
        if($gpu -match 'NVIDIA.*(RTX|GTX 16|GTX 10)') {return 'gpu'}
    } catch {}
    return 'cpu'
}

function Show-Options {
    # All engines are selected in this one installer. Core repair bypasses the
    # optional downloads; reopening normal setup lets users add models later.
    if($CoreOnly){
        $script:MaiaModels=@()
        $script:LeelaMode='none'
        $script:DownloadAllPuzzles=$false
        $script:DesktopShortcut=-not $NoDesktopShortcut
        return
    }
    if($NoGUI){
        $script:MaiaModels=@('5m')
        $script:LeelaMode=Get-GpuMode
        $script:DownloadAllPuzzles=[bool]$AllPuzzles
        $script:DesktopShortcut=-not $NoDesktopShortcut
        return
    }
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()
    $form=New-Object System.Windows.Forms.Form
    $form.Text='Chess Coach - Complete Windows Setup'
    $form.StartPosition='CenterScreen'
    $form.ClientSize=[System.Drawing.Size]::new(622,588)
    $form.FormBorderStyle='FixedDialog';$form.MaximizeBox=$false;$form.MinimizeBox=$false
    $form.Font=[System.Drawing.Font]::new('Segoe UI',[float]9)
    # The Stage 73 ICO was copied to shortcuts but never applied to the actual
    # Windows setup window. Set the Form icon and show our own knight artwork.
    $installerIcon=Join-Path $script:Base 'ChessCoach.ico'
    $installerLogo=Join-Path $script:Base 'Installer-Knight.png'
    $form.Icon=[System.Drawing.Icon]::new($installerIcon)
    $brand=New-Object System.Windows.Forms.PictureBox
    $brand.Image=[System.Drawing.Image]::FromFile($installerLogo)
    $brand.SizeMode=[System.Windows.Forms.PictureBoxSizeMode]::Zoom
    $brand.SetBounds(530,12,70,70)
    $form.Controls.Add($brand)

    $title=New-Object System.Windows.Forms.Label
    $title.Text='Install Chess Coach and chess engines'
    $title.Font=[System.Drawing.Font]::new('Segoe UI',[float]13,[System.Drawing.FontStyle]::Bold)
    $title.SetBounds(22,16,495,32);$form.Controls.Add($title)
    $intro=New-Object System.Windows.Forms.Label
    $intro.Text='Install the compiled Windows app, download selected chess engines and create shortcuts. Python is needed only for Maia-3.'
    $intro.SetBounds(24,58,498,48);$form.Controls.Add($intro)

    $engineTitle=New-Object System.Windows.Forms.Label
    $engineTitle.Text='CHOOSE ENGINES TO INSTALL'
    $engineTitle.Font=[System.Drawing.Font]::new('Segoe UI',[float]9,[System.Drawing.FontStyle]::Bold)
    $engineTitle.SetBounds(24,112,560,20);$form.Controls.Add($engineTitle)
    $stock=New-Object System.Windows.Forms.CheckBox
    $stock.Text='Stockfish 19 - main engine, coaching and Game Review (required)'
    $stock.Checked=$true;$stock.Enabled=$false
    $stock.SetBounds(26,142,560,27);$form.Controls.Add($stock)

    $maiaLabel=New-Object System.Windows.Forms.Label
    $maiaLabel.Text='Maia-3 human-like opponents - choose the models to download:'
    $maiaLabel.SetBounds(26,181,560,23);$form.Controls.Add($maiaLabel)
    $maia5=New-Object System.Windows.Forms.CheckBox
    $maia5.Text='5M (recommended)';$maia5.Checked=$true
    $maia5.SetBounds(41,207,160,25);$form.Controls.Add($maia5)
    $maia23=New-Object System.Windows.Forms.CheckBox
    $maia23.Text='23M';$maia23.SetBounds(222,207,94,25);$form.Controls.Add($maia23)
    $maia79=New-Object System.Windows.Forms.CheckBox
    $maia79.Text='79M';$maia79.SetBounds(342,207,94,25);$form.Controls.Add($maia79)

    $leelaLabel=New-Object System.Windows.Forms.Label
    $leelaLabel.Text='Leela Chess Zero - opponent and neural analysis:'
    $leelaLabel.SetBounds(26,251,350,23);$form.Controls.Add($leelaLabel)
    $leela=New-Object System.Windows.Forms.ComboBox
    $leela.DropDownStyle='DropDownList'
    [void]$leela.Items.Add('NVIDIA GPU / CUDA 12 (approx. 555 MB)')
    [void]$leela.Items.Add('CPU (approx. 23 MB)')
    [void]$leela.Items.Add('Do not install Leela')
    $leela.SelectedIndex=if((Get-GpuMode) -eq 'gpu'){0}else{1}
    $leela.SetBounds(42,277,535,29);$form.Controls.Add($leela)

    $puzzleTitle=New-Object System.Windows.Forms.Label
    $puzzleTitle.Text='OPTIONAL: DOWNLOAD THE COMPLETE PUZZLE LIBRARY'
    $puzzleTitle.Font=[System.Drawing.Font]::new('Segoe UI',[float]9,[System.Drawing.FontStyle]::Bold)
    $puzzleTitle.SetBounds(24,319,566,22);$form.Controls.Add($puzzleTitle)
    $allPuzzlesBox=New-Object System.Windows.Forms.CheckBox
    $allPuzzlesBox.Text='Add all compatible Lichess puzzles (about 6 million)'
    $allPuzzlesBox.Checked=[bool]$AllPuzzles
    $allPuzzlesBox.SetBounds(26,342,565,27);$form.Controls.Add($allPuzzlesBox)
    $puzzleNote=New-Object System.Windows.Forms.Label
    $puzzleNote.Text='Optional: 300+ MB download, several GB of free disk space and a lengthy import. Skip this to install the included starter puzzles only.'
    $puzzleNote.SetBounds(43,371,538,44);$form.Controls.Add($puzzleNote)

    $desktop=New-Object System.Windows.Forms.CheckBox
    $desktop.Text='Create desktop shortcut (Start Menu shortcut always installed)'
    $desktop.Checked=$true;$desktop.SetBounds(26,423,550,27);$form.Controls.Add($desktop)

    $note=New-Object System.Windows.Forms.Label
    $note.Text='Already installed engines are reused where possible. Maia-3 uses its own Python environment. Saved games, progress and backups are preserved.'
    $note.SetBounds(27,457,565,48);$form.Controls.Add($note)

    $go=New-Object System.Windows.Forms.Button
    $go.Text='Install selected components';$go.SetBounds(352,529,242,36)
    $go.DialogResult=[System.Windows.Forms.DialogResult]::OK;$form.Controls.Add($go)
    $cancel=New-Object System.Windows.Forms.Button
    $cancel.Text='Cancel';$cancel.SetBounds(251,529,91,36)
    $cancel.DialogResult=[System.Windows.Forms.DialogResult]::Cancel;$form.Controls.Add($cancel)
    $form.AcceptButton=$go;$form.CancelButton=$cancel
    $res=$form.ShowDialog()
    if($res -ne [System.Windows.Forms.DialogResult]::OK){throw 'Installation cancelled.'}
    $script:MaiaModels=@()
    if($maia5.Checked){$script:MaiaModels+= '5m'}
    if($maia23.Checked){$script:MaiaModels+= '23m'}
    if($maia79.Checked){$script:MaiaModels+= '79m'}
    $script:LeelaMode=@('gpu','cpu','none')[$leela.SelectedIndex]
    $script:DesktopShortcut=$desktop.Checked
    $script:DownloadAllPuzzles=[bool]$allPuzzlesBox.Checked
    $form.Dispose()
    Title 'Chosen components'
    Note 'Stockfish 19: required'
    Note ('Maia-3: '+$(if($script:MaiaModels.Count){$script:MaiaModels -join ', '}else{'not selected'}))
    Note ('Leela: '+$script:LeelaMode)
    Note ('Full Lichess puzzle library: '+$(if($script:DownloadAllPuzzles){'selected'}else{'skipped (starter puzzles remain available)'}))
}

function Check-Platform {
    if(-not [Environment]::Is64BitOperatingSystem){throw 'Chess Coach needs 64-bit Windows.'}
    if([Environment]::OSVersion.Platform -ne 'Win32NT'){throw 'This is a Windows installer.'}
    if(!(Test-Path -LiteralPath (Join-Path $script:Source 'ChessCoach.exe'))){throw 'Installer payload is incomplete. Extract the entire ZIP first.'}
    try {
        $socket=New-Object System.Net.Sockets.TcpClient
        $async=$socket.BeginConnect('127.0.0.1',48319,$null,$null)
        if($async.AsyncWaitHandle.WaitOne(250,$false)){
            try{$socket.EndConnect($async);throw 'Chess Coach is already running. Close the existing app and its console window, then run the installer again.'}
            catch [System.Net.Sockets.SocketException]{}
        }
        $socket.Close()
    } catch [System.Net.Sockets.SocketException] {}
}

function Backup-Progress {
    param([string]$Python)
    if(-not (Test-Path -LiteralPath $script:StateDir -PathType Container)){return}
    # Fail closed BEFORE application files are replaced. SQLite reads include WAL.
    & $Python '--tool' 'backup' '--root' $script:StateDir
    if($LASTEXITCODE -ne 0){throw 'Progress backup failed. Upgrade stopped; existing app files were not changed.'}
    Note 'Verified upgrade backup saved in %LOCALAPPDATA%\ChessCoach\backups'
}

function Copy-Payload {
    Title 'Installing Chess Coach application files'
    New-Item -ItemType Directory -Force -Path $script:InstallDir | Out-Null
    # File-by-file merge, preserving engine/model folders and previously installed runtimes.
    foreach($file in (Get-ChildItem -LiteralPath $script:Source -File -Recurse)) {
        $relative=$file.FullName.Substring($script:Source.Length).TrimStart('\')
        $destination=Join-Path $script:InstallDir $relative
        $parent=Split-Path -Parent $destination
        if(-not (Test-Path -LiteralPath $parent)){New-Item -ItemType Directory -Force -Path $parent|Out-Null}
        Copy-Item -LiteralPath $file.FullName -Destination $destination -Force
    }
    Copy-Item -LiteralPath (Join-Path $script:Base 'ChessCoach-Python.ps1') -Destination (Join-Path $script:InstallDir 'ChessCoach-Python.ps1') -Force
    Copy-Item -LiteralPath (Join-Path $script:Base 'ChessCoach-Start.ps1') -Destination (Join-Path $script:InstallDir 'ChessCoach-Start.ps1') -Force
    Copy-Item -LiteralPath (Join-Path $script:Base 'ChessCoach-Uninstall.ps1') -Destination (Join-Path $script:InstallDir 'ChessCoach-Uninstall.ps1') -Force
    Copy-Item -LiteralPath (Join-Path $script:Base 'ChessCoach-RunTool.ps1') -Destination (Join-Path $script:InstallDir 'ChessCoach-RunTool.ps1') -Force
    # Keep the legacy path for existing integrations, but point NEW shortcuts
    # to a content-named file to avoid stale desktop/Start Menu icon caches.
    Copy-Item -LiteralPath (Join-Path $script:Base 'ChessCoach.ico') -Destination (Join-Path $script:InstallDir 'ChessCoach.ico') -Force
    Copy-Item -LiteralPath (Join-Path $script:Base 'ChessCoach.ico') -Destination (Join-Path $script:InstallDir $script:ContentIconName) -Force
    Copy-Item -LiteralPath (Join-Path $script:Base 'UNINSTALL Chess Coach.bat') -Destination (Join-Path $script:InstallDir 'UNINSTALL Chess Coach.bat') -Force
}

function Install-KittlChessArt {
    Title 'Checking all 21 bundled premium chess piece families'
    # Pre-cut transparent sprites ship with the installer. No Kittl network
    # download is needed and no executable code is downloaded for this step.
    $folder=Join-Path $script:InstallDir 'assets\kittl_sprites'
    $roles=@('k','q','b','n','r','p')
    foreach($set in @('traditional','dragon','fleet','viking','steampunk','gothic','ocean','angels','olympus','highfantasy','arthurian','vampires','gothicvampires','atlantis','cosmic','egyptian','samuraioni','steampunk2','alienshumans','frostpyre','artdeco')){
        foreach($side in @('w','b')){
            foreach($role in $roles){
                $file=Join-Path $folder ($set+'-'+$side+$role+'.png')
                if(-not (Test-Path -LiteralPath $file -PathType Leaf)){
                    throw ('Bundled piece artwork missing: '+(Split-Path -Leaf $file))
                }
            }
        }
    }
    Note 'All 252 transparent chess pieces installed locally (no download required).'
}

function Reuse-VerifiedEngine {
    if(-not $ReuseEngineFrom){return}
    $prior=Join-Path $ReuseEngineFrom 'engine'
    if(-not (Test-Path -LiteralPath (Join-Path $prior 'stockfish.exe'))){throw 'Previous install folder must contain engine\stockfish.exe'}
    Title 'Reusing existing Stockfish and Leela files'
    foreach($file in (Get-ChildItem -LiteralPath $prior -File -Recurse)){
        $relative=$file.FullName.Substring($prior.Length).TrimStart('\')
        $destination=Join-Path (Join-Path $script:InstallDir 'engine') $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force|Out-Null
        if(-not (Test-Path -LiteralPath $destination)){Copy-Item -LiteralPath $file.FullName -Destination $destination}
    }
    Note 'Previous engine files copied. They will be validated before use.'
}

function Install-Stockfish([string]$python) {
    Title 'Setting up official native Stockfish 19'
    $engine=Join-Path $script:InstallDir 'engine\stockfish.exe'
    Push-Location $script:InstallDir
    try {
        if(Test-Path -LiteralPath $engine){
            & $python '--tool' 'verify-stockfish'
            if($LASTEXITCODE -eq 0) { Note 'Stockfish 19 already installed and passed UCI verification.';return }
            Note 'Existing engine failed UCI verification; installing a verified copy.'
        }
        & $python '--tool' 'stockfish'
        if($LASTEXITCODE -ne 0){throw 'Stockfish 19 download or validation failed. Please check your connection and rerun setup.'}
        if(-not (Test-Path -LiteralPath $engine)){throw 'Stockfish installer completed without stockfish.exe.'}
    } finally {Pop-Location}
}

function Install-Option([string]$name,[string]$python,[string[]]$arguments) {
    Title ('Installing optional '+$name)
    Push-Location $script:InstallDir
    try {
        & $python @arguments
        if($LASTEXITCODE -ne 0){Fail ($name+' installation did not complete. Chess Coach and Stockfish will continue working. Rerun the main setup to retry.')}
        else {Note ($name+' installation completed.')}
    } catch {
        Fail ($name+': '+$_.Exception.Message)
    } finally {Pop-Location}
}

function Install-LichessPuzzles([string]$python) {
    if(-not $script:DownloadAllPuzzles){
        Note 'Optional full puzzle download skipped; starter puzzles remain available.'
        return
    }
    Title 'Downloading all compatible rated Lichess puzzles (optional)'
    Note 'Source: https://database.lichess.org/#puzzles (CC0 public-domain dataset)'
    Note 'Expect a download of 300 MB or more, a long import, and several GB of local storage.'
    Note 'This step can be safely retried. Previously imported puzzles and results are preserved.'
    try {
        # Avoid exhausting the system disk mid-import. The additional puzzles
        # alone may use several GB; checking the actual destination drive is vital.
        $driveRoot=[System.IO.Path]::GetPathRoot($script:StateDir)
        $disk=[System.IO.DriveInfo]::new($driveRoot)
        if($disk.AvailableFreeSpace -lt 5GB){
            throw 'Full puzzle import needs at least 5 GB of free space. Free disk space and rerun setup or IMPORT MORE PUZZLES.bat.'
        }
        Push-Location $script:InstallDir
        try {
            & $python '-c' 'import zstandard'
            if($LASTEXITCODE -ne 0){
                Note 'Installing the zstandard reader (required to stream Lichess .zst data)...'
                & $python '-m' 'pip' 'install' '--disable-pip-version-check' 'zstandard>=0.23,<1'
                if($LASTEXITCODE -ne 0){throw 'Could not install zstandard reader.'}
            }
            & $python '--tool' 'puzzles' '--download' '--all'
            if($LASTEXITCODE -ne 0){throw 'The full puzzle import did not finish.'}
        } finally {Pop-Location}
        Note 'Complete Lichess puzzle import finished; Tactics Lab can use the library offline.'
    } catch {
        Fail ('Full puzzle library: '+$_.Exception.Message)
        Note 'Chess Coach is still installed. Retry from IMPORT MORE PUZZLES.bat; existing progress is safe.'
    }
}

function Make-Shortcut([string]$destination,[string]$target,[string]$arguments,[string]$workingDir,[string]$icon) {
    $shell=New-Object -ComObject WScript.Shell
    $sc=$shell.CreateShortcut($destination)
    $sc.TargetPath=$target;$sc.Arguments=$arguments;$sc.WorkingDirectory=$workingDir
    if(-not (Test-Path -LiteralPath $icon)){throw ('Chess Coach icon missing: '+$icon)}
    $sc.IconLocation=($icon+',0')
    $sc.Description='Chess Coach Desktop - Stockfish 19, Maia, Leela and chess training'
    $sc.Save()
}

# Cleanup runs only after new shortcuts and uninstall registry entries are saved.
# Delete ONLY Chess Coach's obsolete version/content-hash ICOs, not user files.
# Retain an older icon if a pinned taskbar shortcut still explicitly uses it.
function Remove-ObsoleteChessCoachIcons {
    $used = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $pinRoot=Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned'
    if(Test-Path -LiteralPath $pinRoot -PathType Container){
        try {
            $shell=New-Object -ComObject WScript.Shell
            foreach($link in (Get-ChildItem -LiteralPath $pinRoot -Recurse -File -Filter '*.lnk' -ErrorAction Stop)) {
                try {
                    $location=$shell.CreateShortcut($link.FullName).IconLocation
                    if($location){
                        $path=($location -replace ',\s*-?\d+$','').Trim('"')
                        if($path){[void]$used.Add([System.IO.Path]::GetFullPath($path))}
                    }
                } catch {
                    Note ('Cannot inspect pinned shortcut '+$link.Name+'; keeping older icons for safety.')
                    return
                }
            }
        } catch {
            # If Windows prevents inspecting the pinned shortcuts, retain older
            # files rather than risking blank icons in existing taskbar pins.
            Note 'Pinned shortcuts could not be checked; keeping legacy icons.'
            return
        }
    }
    $keep=Join-Path $script:InstallDir $script:ContentIconName
    foreach($icon in (Get-ChildItem -LiteralPath $script:InstallDir -File -Filter 'ChessCoach-*.ico' -ErrorAction SilentlyContinue)) {
        if($icon.Name -notmatch '^ChessCoach-(?:v\d+\.\d+|icon-[0-9a-f]{12})\.ico$'){continue}
        if($icon.FullName -ieq $keep -or $used.Contains($icon.FullName)){continue}
        try {
            Remove-Item -LiteralPath $icon.FullName -Force -ErrorAction Stop
            Note ('Removed unused old icon: '+$icon.Name)
        } catch { Note ('Could not remove old icon '+$icon.Name+': '+$_.Exception.Message) }
    }
}

function Add-Shortcuts {
    Title 'Creating Windows shortcuts'
    $ps=(Join-Path $PSHOME 'powershell.exe')
    $target='-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $script:InstallDir 'ChessCoach-Start.ps1')+'"'
    $icon=Join-Path $script:InstallDir $script:ContentIconName
    $menu=Join-Path ([Environment]::GetFolderPath('Programs')) 'Chess Coach.lnk'
    Make-Shortcut $menu $ps $target $script:InstallDir $icon
    $desktop=Join-Path ([Environment]::GetFolderPath('DesktopDirectory')) 'Chess Coach.lnk'
    if($script:DesktopShortcut){
        Make-Shortcut $desktop $ps $target $script:InstallDir $icon
    } elseif(Test-Path -LiteralPath $desktop) {
        # Respect an upgrade's unchecked Desktop shortcut option. Otherwise a
        # stale desktop shortcut could still point at an obsolete icon path.
        Remove-Item -LiteralPath $desktop -Force
    }
    $uninstall=Join-Path $script:InstallDir 'ChessCoach-Uninstall.ps1'
    $key='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ChessCoach'
    New-Item -Path $key -Force|Out-Null
    New-ItemProperty -Path $key -Name 'DisplayName' -Value 'Chess Coach Desktop (Stockfish 19)' -PropertyType String -Force|Out-Null
    New-ItemProperty -Path $key -Name 'DisplayVersion' -Value $script:AppVersion -PropertyType String -Force|Out-Null
    New-ItemProperty -Path $key -Name 'Publisher' -Value 'Chess Coach' -PropertyType String -Force|Out-Null
    New-ItemProperty -Path $key -Name 'InstallLocation' -Value $script:InstallDir -PropertyType String -Force|Out-Null
    New-ItemProperty -Path $key -Name 'DisplayIcon' -Value $icon -PropertyType String -Force|Out-Null
    New-ItemProperty -Path $key -Name 'UninstallString' -Value ('"'+$ps+'" -NoProfile -ExecutionPolicy Bypass -File "'+$uninstall+'"') -PropertyType String -Force|Out-Null
    New-ItemProperty -Path $key -Name 'NoModify' -Value 1 -PropertyType DWord -Force|Out-Null
    New-ItemProperty -Path $key -Name 'NoRepair' -Value 1 -PropertyType DWord -Force|Out-Null
    # Ask Explorer to refresh its icons without restarting the desktop or
    # clearing any user settings. The content-hash icon path changes whenever the artwork changes.
    try {
        if(-not ('ChessCoachShellIconRefresh' -as [type])) {
            Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class ChessCoachShellIconRefresh {
    [DllImport("shell32.dll")]
    public static extern void SHChangeNotify(uint eventId, uint flags, IntPtr item1, IntPtr item2);
}
'@
        }
        [ChessCoachShellIconRefresh]::SHChangeNotify(0x08000000,0,[IntPtr]::Zero,[IntPtr]::Zero)
    } catch { Note 'Windows may need a desktop refresh to show the updated icon.' }
}

function Main {
    if($env:OS -ne 'Windows_NT'){throw 'This package only installs on Windows 10 or 11.'}
    $host.UI.RawUI.WindowTitle='Chess Coach - Installer'
    Title 'Chess Coach Windows Setup'
    Check-Platform
    Show-Options
    Note ('Installation folder: '+$script:InstallDir)
    Note 'Your saves remain at: %LOCALAPPDATA%\ChessCoach'
    $app=Join-Path $script:Source 'ChessCoach.exe'
    Backup-Progress $app
    Copy-Payload
    # This is a completed core copy; old implementation files are no longer used.
    # Keep only the tiny four-file compatibility bridge for clients updating from 1.8.x.
    foreach($old in @('engine_manager.py','game_library.py','health_check.py','import_lichess_puzzles.py','optional_engines.py','performance_metrics.py','player_ratings.py','puzzle_library.py','recovery.py','setup_leela.py','setup_maia3.py','setup_stockfish.py')){
        Remove-Item -LiteralPath (Join-Path $script:InstallDir $old) -Force -ErrorAction SilentlyContinue
    }
    Reuse-VerifiedEngine
    Install-KittlChessArt
    Install-Stockfish (Join-Path $script:InstallDir 'ChessCoach.exe')
    # Install desktop shortcuts before optional downloads, so the working core is available
    # even when an optional third-party model installer encounters an error.
    Add-Shortcuts
    Remove-ObsoleteChessCoachIcons
    $script:InstallCompleted=$true
    foreach($model in $script:MaiaModels){
        if(-not $maiaPython){
            $maiaPython=Find-Python
            if(-not $maiaPython){$maiaPython=Choose-ExistingPython}
            if(-not $maiaPython){$maiaPython=Download-VerifiedPython}
            $env:CHESS_COACH_MAIA_PYTHON=$maiaPython
        }
        Install-Option ('Maia-3 '+$model.ToUpper()) (Join-Path $script:InstallDir 'ChessCoach.exe') @('--tool','maia3','--model',$model)
    }
    if($script:LeelaMode -ne 'none'){
        Install-Option 'Leela Chess Zero' (Join-Path $script:InstallDir 'ChessCoach.exe') @('--tool','leela','--mode',$script:LeelaMode)
    }
    Install-LichessPuzzles (Join-Path $script:InstallDir 'ChessCoach.exe')
    Title 'Selected engine setup complete'
    Write-Host ('Chess Coach is installed at '+$script:InstallDir) -ForegroundColor Green
    Write-Host 'Start it from the Desktop or Start Menu.' -ForegroundColor Green
    if($script:Errors.Count){
        Write-Host "`nOptional installation issues:" -ForegroundColor Yellow
        foreach($err in $script:Errors){Write-Host ('  - '+$err) -ForegroundColor Yellow}
        Write-Host 'Core chess functions are ready. Rerun this installer to retry optional downloads.'
    }
    if(-not $script:Errors.Count){Write-Host 'All selected installation steps finished without an installer error.' -ForegroundColor Green}
    Write-Host "`nYour games, reviews, puzzle results and progress have NOT been reset."
    if(-not $NoGUI -and -not $CoreOnly){
        $yes=[System.Windows.Forms.MessageBox]::Show('Chess Coach is installed. Open the app now?', 'Chess Coach',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Information)
        if($yes -eq [System.Windows.Forms.DialogResult]::Yes){
            Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $script:InstallDir 'ChessCoach-Start.ps1')+'"')
        }
    }
}

try { Main;exit 0 }
catch {
    Write-Host ("`nINSTALLATION ERROR: "+$_.Exception.Message) -ForegroundColor Red
    Write-Host 'The existing Chess Coach data folder was not deleted.' -ForegroundColor Yellow
    Write-Host 'Close this window after reading the error. You can rerun the installer safely.'
    exit 1
}
