CHESS COACH — INSTALACJA W SYSTEMIE WINDOWS
Wersja 1.9.0 | Wersja aplikacji: Payload/VERSION

NOWOŚCI W WERSJI 1.9.0 — PROGRAM SKOMPILOWANY DLA WINDOWS
- Prywatny zestaw źródłowy trzeba najpierw zbudować poleceniem Developer\BUILD COMPILED RELEASE.bat.
- Publiczny instalator zawiera program ChessCoach.exe i skompilowany mechanizm aktualizacji, a nie pełny kod źródłowy Pythona.
- Zachowano zgodność aktualizacji z wersji 1.8.5, kopie zapasowe i możliwość przywrócenia poprzedniej wersji.
- Python jest nadal potrzebny do opcjonalnego silnika Maia-3, ale nie do podstawowej gry.

NOWOŚCI W WERSJI 1.8.5
- Stockfish analizuje pozycje w tle już podczas rozgrywki. Osobny silnik nie zatrzymuje ruchów komputera ani porad trenera. W analizie partii dostępne są wcześniej obliczone wyniki; jedynie brakujące pozycje wymagają sprawdzenia. Postęp jest zapisywany lokalnie i uwzględnia cofnięte ruchy oraz nowe partie.

NOWOŚCI W WERSJI 1.8.3
- Akademia wyjaśnia każdy ruch w 20 wariantach debiutowych i 12 zadaniach: cel, zmiany na szachownicy, dalszy plan, przykładową odpowiedź oraz zagrożenia. Treść dostępna po polsku i angielsku. W ćwiczeniach wyjaśnienie dotyczy wykonanego ruchu i nie zdradza kolejnej odpowiedzi.

NOWOŚCI W WERSJI 1.8.2
- Wydanie do sprawdzenia automatycznej aktualizacji. Uruchom wersję 1.8.1, aby pobrać i zainstalować 1.8.2. Funkcje gry, zapisane partie, ranking i ustawienia zostają zachowane.

NOWOŚCI W WERSJI 1.8.1
- Aplikacja sprawdza aktualizacje przy każdym uruchomieniu, wyświetla powiadomienie i pobiera je automatycznie. Instalacja czeka na zakończenie gry. Wybierz „Później”, aby ją odłożyć. Partia zostaje zapisana, a dane otrzymują kopię zapasową. Aplikacja sprawdza pobrany plik i przywraca poprzednią wersję, jeśli aktualizacja się nie powiedzie. Konto GitHub nie jest potrzebne.

NOWOŚCI W ETAPIE 107
- Obok numeru wersji jest przycisk sprawdzania aktualizacji. Opcjonalne codzienne sprawdzanie szuka opublikowanego instalatora w GitHubie. Konto GitHub nie jest potrzebne. Samodzielnie decydujesz o pobraniu i instalacji. Bez internetu nadal można grać.
- Instalatory: https://github.com/danemcom/chess-coach-updates/releases

NOWOŚCI W ETAPIE 106
- Wyjaśnienie obrony używa prostych nazw figur i mówi wprost, kto może zbić którą figurę. Uproszczono wersję polską i angielską.

NOWOŚCI W ETAPIE 105

Ranking Elo prywatnych partii pojawia się obok graczy online oraz w sekcji Moje postępy. Obaj gracze potrzebują wersji 105 i muszą włączyć partie rankingowe przed rozpoczęciem gry. Wynik początkowy to 1200, a pierwsze 10 partii służy ustaleniu poziomu. Każde tempo gry ma osobny ranking. Wynik liczy się dopiero po potwierdzeniu przez oba komputery. Ranking i historia są przechowywane lokalnie, trafiają do kopii zapasowych i są niezależne od rankingu zadań.
Otwórz Moje postępy, aby zobaczyć ranking, historię i tabelę przeciwników. W sekcji Znajomi obaj gracze powinni pozostawić włączoną opcję liczenia nowych partii do rankingu. Wyłącz ją przed rozpoczęciem gry towarzyskiej.

NOWOŚCI W ETAPIE 104
- Czytelniejsza analiza partii, podgląd legalnych wariantów, odpowiedzi przeciwnika, trzy propozycje ruchu, dokładniejsze ocenianie i pogłębiona analiza wybranego ruchu.

NOWOŚCI W ETAPIE 103
- Przycisk zadań szachowych dopasowano do pozostałych przycisków nagłówka, także na mniejszych ekranach.

NOWOŚCI W ETAPIE 102
- Usunięto nieobsługiwane anonimowe zapytania do bazy mistrzów. Otwórz bieżącą pozycję w eksploratorze Lichess i zaloguj się w tej witrynie. Chess Coach nie wymaga tokenu API.

NOWOŚCI W ETAPIE 101
Przygotowanie debiutowe z wariantami: odpowiedzi przeciwnika, notatki do pozycji, transpozycje, osobne terminy powtórek i przejście z analizy partii. Zewnętrzny eksplorator Lichess po zalogowaniu; zachowano wyszukiwanie lokalne offline. Instrukcja: BRANCHING OPENING PREPARATION.txt.

NOWOŚCI W ETAPIE 100
- Trening pozycji korzysta z dużej szachownicy bez zmieniania zapisanej partii. Wklej FEN lub ustaw bierki, wybierz stronę, siłę przeciwnika i cel, a następnie zagraj ze Stockfishem.
- Przycisk „Graj od tej pozycji” dodano w analizie partii, Akademii, zadaniach, Moim treningu i repertuarze.
- Osiem autorskich lekcji końcówek obejmuje maty hetmanem i wieżami, promocję, pata i obronę przed pionem wieżowym. Decyduje wynik partii; podpowiedzi i cofanie ruchów oznaczają trening z pomocą.
- Mój trening i ponowne próby w analizie uznają sprawdzone alternatywy. Niepewna analiza nie oznacza błędu. Zadania o ustalonej linii i ćwiczenia pamięciowe repertuaru zachowują swoje cele.
- Instrukcja i ograniczenia: POSITION PRACTICE AND ENDGAMES.txt.

INSTALACJA
1. Zamknij Chess Coach i rozpakuj CAŁE archiwum ZIP do nowego folderu.
2. Uruchom INSTALL CHESS COACH.bat. Nie przenoś plików z folderu Payload.
3. Wybierz opcjonalne silniki Maia/Leela. Wymagany Stockfish 19 instaluje się automatycznie, jeśli go brakuje.
   Możesz też zaznaczyć „Add all compatible Lichess puzzles”, aby pobrać pełny zbiór zadań.
   Bez zaznaczenia tej opcji zostaną standardowe zadania i instalacja nie pobierze dużej bazy.
4. Uruchom program ze skrótu na pulpicie lub w menu Start. Instalator nadaje ikonie nazwę zależną od grafiki: jeśli obraz się nie zmieni, kolejne aktualizacje korzystają z tego samego pliku. Stare, nieużywane ikony są usuwane.
5. W górnym pasku wybierz Polski. W menu Wygląd znajdziesz szachownice i bierki.

NOWOŚCI W WERSJI 99
- Limity wiadomości i kolejki oraz bezpieczniejszy kanał widza.
- Więcej czasu na uruchomienie uśpionej, bezpłatnej usługi połączeń.
- Anulowanie przerywa oczekiwanie i nie zakłóca nowszej próby połączenia.
- Ograniczony rozmiar odpowiedzi, brak przekierowań i sprawdzane listy znajomych.

NOWOŚCI W WERSJI 98
- Jaśniejsze wyjaśnienia obrony, odpowiedź przeciwnika i twój dalszy ruch.
- Konkretna obrona przed szachem, odbicia, obrońcy, podwójne ataki i związania.
- Dodatkowa analiza odpowiedzi i porównanie twojego ruchu wyjaśniają dalszy ciąg.
- Poradnik: COACHING GUIDE EN-PL.txt.

NOWOŚCI W WERSJI 97
- Opcjonalne zegary w grze z komputerem, lokalnej dla dwóch osób i online.
- Wybierz grę bez zegara, gotowe tempo lub własny czas i dodatek po ruchu.
- Lokalnie możesz wstrzymać zegar i cofnąć ruch wraz z jego stanem.
- Zapis bieżącej partii wczytuje zegary wstrzymane.
- Gra online na czas wymaga wersji 97 lub nowszej u obu graczy. Tempo wybiera gospodarz.
- Zasady zegarów i wznowienia opisano po polsku w CLOCKS GUIDE.txt.

NOWOŚCI W WERSJI 96
- Wszystkie 21 szachownic jest teraz pozbawionych dekoracyjnych ram.
- Zachowano tekstury i precyzyjne wyrównanie 64 pól, bez zmiany ruchów figur.

NOWOŚCI W WERSJI 94
- Poprawiono błąd, przez który komputer czasem nie odpowiadał po ruchu gracza,
  gdy trener nadal sprawdzał zagrożenia w tle.
- Sprawdzanie w tle jest przerywane, zanim silnik zacznie szukać kolejnego ruchu.
- Przed aktualizacją zamknij aplikację. Po instalacji uruchom ją ze zwykłego skrótu.

NOWOŚCI W WERSJI 93
- Zapis partii i analiz zachowuje dane właściwej gry także przy opóźnionych odpowiedziach.
- Nowszy wybór archiwum lub PGN zastępuje starszy. Zmieniona partia pozostaje na miejscu.
- Anulowanie i ponowne otwarcie analizy chroni nowe wyniki przed starszymi odpowiedziami.
- Zapisane analizy są sprawdzane pod kątem zgodności z rzeczywistymi ruchami.
- Rozłącz grę online przed otwarciem lub importem zapisanej partii. Analizę otworzysz
  po zakończeniu partii online, również po poddaniu.
- Przy błędzie archiwizacji możesz skorzystać z dotychczasowej propozycji kopii PGN.

NOWOŚCI W WERSJI 92
- Przycisk Krótkie wprowadzenie obok Kopii zapasowych otwiera sześć tematów przewodnika.
- Poznaj kolory ruchów, złote gwiazdki, pomoc trenera i zadania, a potem wypróbuj funkcje.
- Oznaczaj tematy jako przeczytane. Przewodnik pamięta miejsce i zachowuje bieżącą partię.
- W przewodniku wybierzesz English lub Polski. To ustawienie języka całej aplikacji.
- Przyciski ćwiczeń uwzględniają kolejkę gracza, pracę silnika i ograniczenia gry online.

NOWOŚCI W WERSJI 91
- Szybsze odświeżanie wyników zadań i postępów przy dużej historii.
- Zapis odpowiedzi aktualizuje ostatnie wyniki motywów bez przeglądania całej historii.
- Podsumowania odświeżają się po zmianie danych, terminu powtórki lub wybranego okresu.
- Wyniki i zasady doboru trudności zostają zachowane. Nie potrzeba aktualizacji serwera.

NOWOŚCI W WERSJI 90
- W panelu postępów wybierz ostatnie 7 dni, ostatnie 30 dni lub całą historię.
- Zobacz powtarzające się problemy, porównania faz partii i wyniki motywów taktycznych.
- Otwórz przykład z zapisanej partii lub rozpocznij ćwiczenia wybranego motywu.
- Sesja ćwiczeń dobiera pozycje do powtórki według priorytetów wybranego okresu.
- Bieżące terminy i podsumowania ze wszystkich dat są wyraźnie opisane.
- Zasady pomiaru opisano także po polsku w LEARNING PROGRESS GUIDE.txt.

NOWOŚCI W WERSJI 89
- Zaproszenia do znajomych z wersji 89 są zapisywane na obu komputerach. Widać wysłane
  zaproszenia, można je anulować i oznaczać powiadomienia jako przeczytane. Akceptacja nadal jest wymagana.
- Po partii online otwórz panel znajomych i zaproponuj rewanż bez nowego kodu pokoju.
  Obaj gracze potrzebują wersji 89 lub nowszej. Zakończona partia zostanie zapisana, a kolory zamienione.
- Dotychczasowa usługa połączeń i znajomych działa bez aktualizacji serwera.

NOWOŚCI W WERSJI 88
- W panelu znajomych wybierz „Wznów przerwaną partię” i utwórz nowy kod dla tego samego przeciwnika.
  Obaj gracze muszą mieć wersję 88 lub nowszą. Partia musi być rozpoczęta z obsługą wznowienia.
- W panelu trenera pojawia się krótkie wyjaśnienie twojego ostatniego ruchu. Po rozwinięciu
  można porównać go ze Stockfishem. Funkcję wyłączysz w zaawansowanych ustawieniach silnika.
- Wznowienie nadal wymaga działającego połączenia bezpośredniego między graczami.

CO ZAWIERA APLIKACJA
- 21 szachownic premium z siatką 8 × 8, każda w rozdzielczości 2048 × 2048 pikseli.
- 21 zestawów bierek i 252 pliki PNG z przezroczystym tłem (256 × 256 pikseli).
- Analizę silnikiem Stockfish 19, przegląd partii, Akademię, bibliotekę i ćwiczenia taktyczne.
- Podpowiedzi, naukę na błędach, trening dopasowany do umiejętności i powtórki zadań.
- Dodatkową analizę możliwych odpowiedzi przeciwnika i sprawdzanie realnych groźb.
- Automatyczne sprawdzanie do 3 możliwych ofiar po zaznaczeniu bierki w trybie ćwiczeń. Złota gwiazdka oznacza wstępne potwierdzenie przez Stockfisha; trener przypomina o zagranej ofierze.
- Polski i angielski. Po polsku ruchy są wyświetlane jako np. Sf3 i Hd7; pliki PGN zachowują standardowy zapis.
- W wersji 87 poprawiono naturalność porad i przetłumaczono także nowe ekrany znajomych, kopii zapasowych, wprowadzenia oraz postępów.

SPRAWDZANIE GROŹBY — ETAP 60
Program może sprawdzić, jaką taktykę wskazałby Stockfish, gdyby obecny gracz hipotetycznie opuścił kolejkę. To tylko eksperyment myślowy: w prawdziwej partii nie można opuścić ruchu. Nie uruchamia się tego sprawdzenia, gdy król jest szachowany. Pokazujemy wyłącznie konkretne groźby, których wskazany ruch faktycznie unika.


ZŁOTA GWIAZDKA — ETAP 63
Włącz tryb ćwiczeń i zaznacz bierkę. Program automatycznie sprawdza w Stockfishie do trzech ruchów, które pozornie oddają materiał. Gwiazdka ★ pojawia się, jeśli krótka analiza wskazuje rekompensatę (po ruchu ocena nie spada poniżej około -0,75 pionka, a ruch jest bliski najlepszemu) albo wymuszonego mata dla ciebie. To wskazówka, a nie gwarancja, że ruch jest najlepszy. Sprawdzanie nie wykonuje ruchów i można je przerwać. Po zagraniu sprawdzonej ofiary jej wyjaśnienie pozostaje w panelu trenera.

POMOC I AKTUALIZACJE
- REPAIR CORE INSTALL.bat naprawia instalację bez usuwania zapisanych partii.
- CHECK CHESS COACH.bat sprawdza lokalną instalację.
- ETAP 67 — PEŁNA BAZA ZADAŃ (OPCJONALNIE): Podczas instalacji możesz pobrać
  wszystkie zgodne zadania z oficjalnej bazy Lichess CC0 (około 6 mln; liczba zmienia się przy aktualizacjach).
  Wymaga to ponad 300 MB transferu, kilku GB miejsca na dysku i dłuższego importowania.
  Instalator sprawdza, czy dostępne jest co najmniej 5 GB wolnego miejsca.
  Pobieranie jest opcjonalne; pełna baza NIE jest dołączona do archiwum instalatora.
  Dodawane są tylko poprawne, zgodne pozycje. Twoje wyniki, rankingi i terminy powtórek
  pozostają bez zmian. Przerwany import można bezpiecznie uruchomić ponownie.
- IMPORT MORE PUZZLES.bat pozwala później wybrać pełną bazę albo 20 000 zadań.
- Partie i postępy pozostają w %LOCALAPPDATA%\ChessCoach.
- Podczas instalacji nowych silników może być wymagany internet.
- CHANGELOG_EN.txt i CHANGELOG_PL.txt zawierają historię zmian.

DIAGNOSTYKA: CHECK CHESS COACH.bat sprawdza również ocenę mata w dwóch ruchach w silniku Stockfish.

UWAGA O IKONIE: Jeśli aplikacja była przypięta do paska zadań, odepnij stary skrót i przypnij ponownie nowy skrót z pulpitu lub menu Start.
