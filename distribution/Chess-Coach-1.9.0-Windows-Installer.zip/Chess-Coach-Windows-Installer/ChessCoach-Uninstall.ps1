$ErrorActionPreference='Stop'
$installation=Join-Path $env:LOCALAPPDATA 'Programs\Chess Coach'
$data=Join-Path $env:LOCALAPPDATA 'ChessCoach'
try {
    Add-Type -AssemblyName System.Windows.Forms
    $message='Remove Chess Coach application and optional installed engines? Your saved games, reviews, settings and training databases will be KEPT.'
    $answer=[System.Windows.Forms.MessageBox]::Show($message,'Uninstall Chess Coach',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
    if($answer -ne [System.Windows.Forms.DialogResult]::Yes){exit 0}
    $menu=Join-Path ([Environment]::GetFolderPath('Programs')) 'Chess Coach.lnk'
    $desktop=Join-Path ([Environment]::GetFolderPath('DesktopDirectory')) 'Chess Coach.lnk'
    foreach($item in @($menu,$desktop)){if(Test-Path -LiteralPath $item){Remove-Item -LiteralPath $item -Force}}
    $key='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ChessCoach'
    if(Test-Path -LiteralPath $key){Remove-Item -LiteralPath $key -Recurse -Force}
    if(Test-Path -LiteralPath $installation){Remove-Item -LiteralPath $installation -Recurse -Force}
    [void][System.Windows.Forms.MessageBox]::Show(('Uninstalled. Your saved progress remains here:'+"`n"+$data),'Chess Coach',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information)
} catch {
    Write-Host ('Uninstall failed: '+$_.Exception.Message) -ForegroundColor Red
    Read-Host 'Press Enter to close';exit 1
}
