@echo off
setlocal
cd /d "%~dp0"
if not exist "Payload\server.py" (
    echo Extract the whole Chess Coach ZIP before running this repair tool.
    pause
    exit /b 1
)
echo Chess Coach - Repair core app and Stockfish without optional neural downloads
echo.
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0ChessCoach-Setup.ps1" -CoreOnly
if errorlevel 1 (
 echo.
 echo Setup could not finish. Read the error message above.
 pause
 exit /b 1
)
echo.
echo Repair completed. Your existing game progress was preserved.
pause
endlocal
