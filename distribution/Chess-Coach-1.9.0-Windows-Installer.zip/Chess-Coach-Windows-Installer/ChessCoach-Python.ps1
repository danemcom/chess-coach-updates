﻿# Shared Python discovery for Chess Coach (Windows PowerShell 5.1+).
# Always test that the selected interpreter can actually run: PATH aliases alone
# are not evidence of an installed Python runtime.
function Test-ChessCoachPython {
    param([string]$Command,[string[]]$Prefix=@())
    if([string]::IsNullOrWhiteSpace($Command)){return $null}
    $code='import sys;print(sys.executable);print(str(sys.version_info.major)+chr(46)+str(sys.version_info.minor));print(64 if sys.maxsize>4294967295 else 32)'
    $proc=$null
    try {
        $info=New-Object System.Diagnostics.ProcessStartInfo
        $info.FileName=$Command
        $info.Arguments=((@($Prefix) -join ' ')+' -c "'+$code+'"').Trim()
        $info.UseShellExecute=$false
        $info.RedirectStandardOutput=$true
        $info.RedirectStandardError=$true
        $info.CreateNoWindow=$true
        $proc=New-Object System.Diagnostics.Process
        $proc.StartInfo=$info
        if(-not $proc.Start()){return $null}
        if(-not $proc.WaitForExit(12000)){
            try{$proc.Kill()}catch{}
            return $null
        }
        if($proc.ExitCode -ne 0){return $null}
        $stdout=$proc.StandardOutput.ReadToEnd()
        $lines=@($stdout -split "[`r`n]+" | Where-Object {$_.Trim().Length -gt 0})
        if($lines.Count -lt 3){return $null}
        $python=([string]$lines[$lines.Count-3]).Trim()
        $version=([string]$lines[$lines.Count-2]).Trim()
        $architecture=([string]$lines[$lines.Count-1]).Trim()
        if($version -notmatch '^3\.(10|11|12|13|14)$'){return $null}
        if($architecture -ne '64'){return $null}
        if(-not (Test-Path -LiteralPath $python -PathType Leaf)){return $null}
        return $python
    } catch {return $null}
    finally {if($null -ne $proc){$proc.Dispose()}}
}

function Find-ChessCoachPython {
    param([string]$AppFolder)
    $locations=New-Object 'System.Collections.Generic.List[string]'
    if($env:CHESS_COACH_PYTHON){$locations.Add($env:CHESS_COACH_PYTHON)}
    if($AppFolder){
        $selection=Join-Path $AppFolder 'python-path.txt'
        if(Test-Path -LiteralPath $selection){
            try {
                $chosen=(Get-Content -LiteralPath $selection -Raw -Encoding UTF8).Trim().Trim([char]0xFEFF)
                if($chosen){$locations.Add($chosen)}
            }catch{}
        }
        $locations.Add((Join-Path $AppFolder 'Python313\python.exe'))
    }
    foreach($v in @('314','313','312','311','310')){
        $locations.Add((Join-Path $env:LOCALAPPDATA ('Programs\Python\Python'+$v+'\python.exe')))
        $locations.Add((Join-Path $env:LOCALAPPDATA ('Programs\Python\Python'+$v+'-64\python.exe')))
        $locations.Add((Join-Path $env:USERPROFILE ('AppData\Local\Programs\Python\Python'+$v+'\python.exe')))
        if($env:ProgramFiles){$locations.Add((Join-Path $env:ProgramFiles ('Python'+$v+'\python.exe')))}
    }
    # Python may also be installed by the Python Install Manager (including 3.14).
    # Try both the legacy launcher syntax and its compatible -V tag syntax.
    foreach($version in @('3.14','3.13','3.12','3.11','3.10')){
        $found=Test-ChessCoachPython -Command 'py' -Prefix @('-'+$version)
        if($found){return $found}
        $found=Test-ChessCoachPython -Command 'py' -Prefix @('-V:'+$version)
        if($found){return $found}
    }
    # PEP 514 registrations (per-user or system-wide installations).
    foreach($regRoot in @(
        'Registry::HKEY_CURRENT_USER\Software\Python\PythonCore',
        'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Python\PythonCore',
        'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Python\PythonCore'
    )){
        if(-not (Test-Path -LiteralPath $regRoot)){continue}
        foreach($entry in @(Get-ChildItem -LiteralPath $regRoot -ErrorAction SilentlyContinue)){
            $installKey=Join-Path $entry.PSPath 'InstallPath'
            if(-not (Test-Path -LiteralPath $installKey)){continue}
            try {
                $props=Get-ItemProperty -LiteralPath $installKey -ErrorAction Stop
                if($props.ExecutablePath){$locations.Add([string]$props.ExecutablePath)}
                $defaultPath=(Get-Item -LiteralPath $installKey).GetValue('')
                if($defaultPath){$locations.Add((Join-Path ([string]$defaultPath) 'python.exe'))}
            } catch {}
        }
    }
    # Common command names and WindowsApps aliases (the latter are validated).
    foreach($cmd in @('python','python3','python3.14','python3.13','python3.12','python3.11','python3.10','py')){
        $found=Test-ChessCoachPython -Command $cmd
        if($found){return $found}
    }
    foreach($cmd in @('python.exe','python3.exe','py.exe')){
        try{
            foreach($exe in @(Get-Command $cmd -All -ErrorAction SilentlyContinue)){
                if($exe.Source){$locations.Add([string]$exe.Source)}
            }
        }catch{}
    }
    # Prefer an already installed, working Python over reinstalling one.
    foreach($candidate in $locations){
        if([string]::IsNullOrWhiteSpace($candidate)){continue}
        if(-not (Test-Path -LiteralPath $candidate -PathType Leaf)){continue}
        $found=Test-ChessCoachPython -Command $candidate
        if($found){return $found}
    }
    return $null
}
