CHESS COACH — WINDOWS INSTALLER
Version 1.9.0 | Full version: Payload/VERSION

NEW IN 1.9.0 — COMPILED WINDOWS EDITION
- The Windows build must be compiled first using Developer\BUILD COMPILED RELEASE.bat (private build kit only).
- The distributed installer contains ChessCoach.exe and a separate compiled update worker, not readable Python chess logic.
- A small compatibility bridge lets 1.8.5 accept the compiled update while preserving game data and rollback.
- Optional Maia-3 installation still needs Python. No Python download is required for the core Chess Coach app.

NEW IN VERSION 1.8.5
- Stockfish reviews the actual positions in the background as moves are played, on a separate engine so opponent moves and coaching are not interrupted. Open Game review to use completed results immediately; only unfinished positions need additional analysis. Saves progress locally, resumes after reopening and handles takebacks/new games.

NEW IN VERSION 1.8.3
- Academy now explains every move in all 20 opening lines and all 12 puzzles: the purpose, board changes, wider plan, example replies and what to watch for. English and Polish included. Practice explains moves already played without revealing the next answer.

NEW IN VERSION 1.8.2
- Test release for the automatic updater. Open version 1.8.1 to detect, download and install 1.8.2. Your chess features, games, ratings and settings are retained.

NEW IN VERSION 1.8.1
- Checks on every launch, shows an update popup and downloads automatically. Installation waits until no game is in progress; choose Later to postpone it. Your game is saved and backed up first. Download checksums and startup checks protect installation, with rollback if it fails. No GitHub account is needed.

NEW IN STAGE 107
- Use Check for updates beside the version number. Optional daily checks look for a published Windows installer on GitHub. No GitHub account is needed. Download and install only when you choose; the game remains usable offline.
- Public installers: https://github.com/danemcom/chess-coach-updates/releases

NEW IN STAGE 106
- Defensive advice uses simple piece names and explains who can take which piece, without algebraic move codes or phrases such as "legal recapture". English and Polish updated.

NEW IN STAGE 105

Private-match Elo ratings are shown beside online players and under My progress. Both players need Stage 105 and must enable rated matches before starting. Ratings start at 1200, remain provisional for 10 games, and use separate time-control pools. Wins, draws and losses count only after both PCs confirm the same result. Ratings and history are local, included in personal backups, and are separate from puzzle ratings.
Open My progress to see your rating, history and opponent table. In Friends, leave "Rate new private matches" enabled on both PCs to play for rating. Turn it off before starting for a casual game.

NEW IN STAGE 104
- Clearer game review, legal continuation previews, opponent replies, three candidate lines, fairer grading and deeper checks for a selected move.

NEW IN STAGE 103
- The Tactics header button now uses the same text size, icon size and padding as the other toolbar buttons, including compact layouts.

NEW IN STAGE 102
- Removed the unsupported anonymous Masters API lookup. Open the current position in Lichess Explorer and sign in on Lichess. No API token setup in Chess Coach.

NEW IN STAGE 101
Branching opening preparation: opponent choices, position notes, transpositions, independent branch review dates and a game-review handoff. External Lichess Explorer link (sign in on Lichess); offline local search retained. See BRANCHING OPENING PREPARATION.txt.

INSTALLATION
1. Close Chess Coach, then extract this entire ZIP into a new folder.
2. Run INSTALL CHESS COACH.bat (do not move files out of Payload).
3. Choose optional Maia/Leela downloads if wanted. Stockfish 19 is the required engine.
   To download the COMPLETE Lichess CC0 rated puzzle library, tick "Add all compatible Lichess puzzles".
   Leave it unticked to keep the bundled starter puzzles and avoid the large download.
4. Launch from the desktop or Start Menu shortcut. Setup uses an icon filename based on the gold-knight artwork. Updates reuse it until the artwork changes; unused older icon files are cleaned up.
5. Open Appearance to select a board or a piece set. English / Polski is at the top.

NEW IN STAGE 100
- Position practice uses the large board without changing your saved game. Paste FEN or set up pieces, choose a side/strength/goal, and play Stockfish.
- Play from here is available in review, Academy, Tactics, My Training and Repertoire.
- Eight original endgame lessons cover queen/rook mates, promotion, stalemate and rook-pawn defence. Actual results determine completion; hints/takebacks count as guided practice.
- Personal Practice and review retry accept verified alternatives. Inconclusive searches do not mark a move wrong. Fixed-line puzzles and repertoire memory tasks retain their intended goals.
- See POSITION PRACTICE AND ENDGAMES.txt for instructions and limits.

NEW IN STAGE 99
- Safer online queues, message limits and spectator channel handling.
- Longer first-contact allowance for a sleeping free connection service.
- Cancel stops a pending room request without affecting a newer attempt.
- Redirect-free, bounded service replies and validated friend lists.

NEW IN STAGE 98
- Clearer defensive coaching with the opponent's analysed reply and your answer.
- Specific check evasions, recaptures, useful defenders, double attacks and pins.
- Optional reply exploration and own-move comparison explain the continuation.
- Read COACHING GUIDE EN-PL.txt.

NEW IN STAGE 97
- Optional clocks for computer, local two-player and private online games.
- Choose Untimed, 3+2, 5+0, 10+5, 15+10, 30+0 or custom minutes/increments.
- Local pause/resume, takeback clock restoration and paused current-game restart.
- Timed online games require Stage 97 or later on both PCs; the host chooses the control.
- Read CLOCKS GUIDE.txt for timing, timeout and reconnection behaviour.

NEW IN STAGE 96
- All 21 chessboards are now borderless without losing their original textures.
- Playing squares remain perfectly aligned; animated moves and chess behaviour are unchanged.

NEW IN STAGE 94
- Fixed a computer-turn stall when a background coach threat check was still running.
- The background check stops before the next turn starts its engine search.
- Close the app before installing this update, then launch it from the usual shortcut.

NEW IN STAGE 93
- Archive saves and game reviews keep the original game's data during delayed work.
- Newer archive/PGN choices supersede older requests; a changed current game is kept.
- Cancelling and reopening review protects the new analysis from old responses.
- Saved reviews are checked against actual moves before being reused.
- Disconnect online play before opening/importing a saved game. Review is available
  after an online game finishes, including resignation.
- The existing PGN-backup choice protects a game when archiving fails.

NEW IN STAGE 92
- Open Quick introduction beside Backup / Restore for the six-topic beginner guide.
- Learn the move colours, gold stars, coach and puzzles, then try the existing tools.
- Mark topics as read; the guide remembers your place. Browsing keeps your game.
- Choose English or Polski inside the guide. This changes the app's language setting.
- Practice/coach buttons respect turn, analysis and online-play restrictions.

NEW IN STAGE 91
- Faster repeated puzzle statistics and progress refreshes with a large history.
- Normal answer saves update recent skill samples without rereading old attempts.
- Cached results refresh when data, review deadlines or period boundaries change.
- Saved results and difficulty rules are retained. No server update is needed.

NEW IN STAGE 90
- Open My progress and choose Last 7 days, Last 30 days or All saved history.
- See recurring issues across games, phase comparisons and puzzle skill trends.
- Open a saved example or start adaptive practice for a particular skill.
- Focus uses due positions with priorities from your selected period.
- Current review schedules and lifetime practice/repertoire totals are labelled.
- Read LEARNING PROGRESS GUIDE.txt for sample sizes and date rules.

NEW IN STAGE 89
- Stage 89 friends invitations persist on both PCs, with pending lists, cancellation
  and read/unread notification counts. The other player still has to accept.
- After an online game, open Friends to request a rematch without a new room code.
  Both players need Stage 89 or later. The finished game is saved and colours are swapped.
- The existing connection/friends service works without a deployment update.

NEW IN STAGE 88
- Friends > Resume an interrupted game creates a new recovery code for the same opponent.
  Both PCs must run Stage 88 or later, and the match must have started with recovery support.
- Your coach now includes a compact explanation of your own last move. Expand it for
  an optional Stockfish comparison. Engine > Advanced settings lets you turn it off.
- Recovery still needs a working direct network connection; no game relay was added.

WHAT IS INCLUDED
- 21 premium boards, each with an 8 x 8 playing grid. 21 full-board images, 2048 x 2048 pixels.
- 21 piece families; 252 transparent PNG sprites, 256 x 256 pixels each.
- Native Stockfish 19; Game Review and locally stored games; Chess Academy.
- Tactics Lab with progressive clues, adaptive difficulty, five-puzzle sprints and solution replay.
- Personal Training and Today's Focus, recurring weakness tracking and skill progress.
- Optional opponent-reply analysis and verified threat checks during coaching.
- Practice mode checks up to 3 likely sacrifices automatically after piece selection; gold stars mark preliminary Stockfish-supported tactical opportunities. The last verified move remains explained in Your coach after it is played.
- English and revised, natural Polish throughout coaching and the newer friends, backup, introduction and progress screens. Displayed moves use Polish initials when selected; PGN exports remain standard.

THREAT CHECK (STAGE 60)
A short secondary Stockfish search can inspect an imaginary position after the current side skips a turn. Skipping is ILLEGAL in chess; this diagnostic is never shown when the current king is in check. Chess Coach reports only a concrete checked tactic that the recommended move prevents. No engine can guarantee every threat has been eliminated.


GOLD STAR (STAGE 63)
Select a piece with Practice mode enabled. If an immediate capture would lose material, Chess Coach automatically tests up to three promising candidates with native Stockfish. A gold ★ appears only when the limited search supports compensation (the resulting position is no worse than approximately -0.75 pawns and the move is near-best) or a forced mate for you. The result is provisional: no guarantee that a sacrifice is best. Searching is cancellable and never plays a move. The coach remembers the latest verified sacrifice after you play it. An unavailable/busy engine may require manual verification.

FILES AND DOCUMENTATION
Payload/VERSION is the only release-version source. CHANGELOG_EN.txt and CHANGELOG_PL.txt record the release history.

HELP AND REPAIR
- REPAIR CORE INSTALL.bat repairs the app and Stockfish while preserving saved data.
- CHECK CHESS COACH.bat runs local diagnostics, including a short Stockfish UCI mate-in-two score-direction check.
- OPTIONAL FULL PUZZLE LIBRARY (STAGE 67): The setup checkbox streams the official Lichess
  CC0 dataset (about 6 million rated puzzles (dataset size varies)). Expect a 300+ MB
  internet download, several GB of local database storage and a lengthy import.
  Setup requires at least 5 GB free on the data drive before starting this option.
  Only compatible valid puzzle rows are added. The importer saves batches as it goes,
  ignores IDs already present, and never resets your scores or spaced-repetition history.
  An interrupted transfer can be restarted: previously imported rows remain saved.
  The full dataset is NOT bundled in this installer; puzzles are downloaded only if chosen.
- IMPORT MORE PUZZLES.bat lets you add the COMPLETE dataset or a smaller 20,000-puzzle
  sample later. It is safe to rerun to collect missing puzzles or retry an interrupted import.
- User data resides in %LOCALAPPDATA%\ChessCoach and is backed up during installation.
- First installation may require an internet connection to download the selected engines/Python.
- Installer is unsigned and requires Windows 10/11 64-bit.

THIRD-PARTY LICENSES
Stockfish and Lichess notices are retained under Payload\licenses. Engine software has its own license and attribution.

ICON NOTE: If you previously pinned Chess Coach to the Windows taskbar, unpin the old icon and pin the newly created Desktop/Start Menu shortcut. Older taskbar pins may retain an outdated cached image.


STAGE 78 MULTIPLAYER: Read MULTIPLAYER GUIDE.txt. New codes are compressed; invitation files remove the need to copy long text. Both players should update for the new format.
