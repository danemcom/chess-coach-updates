@echo off
setlocal
set "RUNNER=%~dp0ChessCoach-RunTool.ps1"
if not exist "%RUNNER%" set "RUNNER=%~dp0..\ChessCoach-RunTool.ps1"
if not exist "%RUNNER%" (
 echo The Chess Coach installer files are missing.
 pause
 exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%RUNNER%" -Tool health
if errorlevel 1 echo One or more checks need attention. Re-run INSTALL CHESS COACH.bat if needed.
pause
endlocal
