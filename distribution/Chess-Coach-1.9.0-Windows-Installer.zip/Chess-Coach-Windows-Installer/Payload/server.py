"""1.8.x update bridge; no application implementation is included."""
import subprocess,sys
from pathlib import Path
if __name__=='__main__':
    exe=Path(__file__).resolve().with_name('ChessCoach.exe')
    raise SystemExit(subprocess.call([str(exe),*sys.argv[1:]],cwd=str(exe.parent)))
