# Legacy 1.8.x update-extraction compatibility; implementation is compiled in ChessCoach.exe.
