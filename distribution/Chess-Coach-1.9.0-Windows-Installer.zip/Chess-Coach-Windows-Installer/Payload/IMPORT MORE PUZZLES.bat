@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ChessCoach-RunTool.ps1" -Tool puzzles
if errorlevel 1 (
 echo Setup did not complete. Read the message above.
 pause
 exit /b 1
)
echo Setup completed.
pause
endlocal
